package com.lyfestyle.music

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** A song found on the device through MediaStore. */
data class Song(
    val id: Long,
    val title: String,
    val artist: String?,
    val album: String?,
    val albumId: Long,
    val durationMs: Long,
    val dateAdded: Long = 0L
) {
    val uri: Uri
        get() = ContentUris.withAppendedId(
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL), id
        )

    /** Legacy album-art URI, used by the media notification. */
    val artUri: Uri
        get() = ContentUris.withAppendedId(
            Uri.parse("content://media/external/audio/albumart"), albumId
        )
}

/** Scans the device music library. Never returns fake data. */
object MediaScanner {
    private fun clean(s: String?): String? =
        s?.takeIf { it.isNotBlank() && it != MediaStore.UNKNOWN_STRING }

    suspend fun scan(context: Context, minMs: Long = 10_000L): List<Song> = withContext(Dispatchers.IO) {
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= $minMs"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val result = ArrayList<Song>()
        val cursor = context.contentResolver.query(collection, projection, selection, null, sort)
            ?: return@withContext result
        cursor.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val addedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            while (c.moveToNext()) {
                result.add(
                    Song(
                        id = c.getLong(idCol),
                        title = clean(c.getString(titleCol)) ?: "—",
                        artist = clean(c.getString(artistCol)),
                        album = clean(c.getString(albumCol)),
                        albumId = c.getLong(albumIdCol),
                        durationMs = c.getLong(durCol),
                        dateAdded = c.getLong(addedCol)
                    )
                )
            }
        }
        result
    }
}

/** Custom covers chosen by the user, stored in the app's private folder. */
object CoverStore {
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version

    fun file(context: Context, songId: Long): File =
        File(File(context.filesDir, "covers"), "$songId.jpg")

    fun has(context: Context, songId: Long): Boolean = file(context, songId).exists()

    suspend fun save(context: Context, songId: Long, uri: Uri): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, bounds)
                }
                var sample = 1
                while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, opts)
                } ?: return@withContext false
                val f = file(context, songId)
                f.parentFile?.mkdirs()
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                ArtworkLoader.clear(songId)
                _version.value = _version.value + 1
                true
            } catch (e: Exception) {
                false
            }
        }

    fun clearAll(context: Context) {
        File(context.filesDir, "covers").listFiles()?.forEach { it.delete() }
        ArtworkLoader.clearAll()
        _version.value = _version.value + 1
    }

    fun remove(context: Context, songId: Long) {
        file(context, songId).delete()
        ArtworkLoader.clear(songId)
        _version.value = _version.value + 1
    }
}

/** Loads cover art (custom cover first, then the system thumbnail) and caches it. */
object ArtworkLoader {
    private val cache = LruCache<String, Bitmap>(80)

    fun clearAll() {
        cache.evictAll()
    }

    fun clear(songId: Long) {
        val prefix = "${songId}_"
        cache.snapshot().keys.filter { it.startsWith(prefix) }.forEach { cache.remove(it) }
    }

    private fun decodeScaled(file: File, px: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }

    suspend fun load(context: Context, song: Song, px: Int): Bitmap? {
        val key = "${song.id}_$px"
        cache.get(key)?.let { return it }
        val bmp = withContext(Dispatchers.IO) {
            val custom = CoverStore.file(context, song.id)
            if (custom.exists()) {
                decodeScaled(custom, px)
            } else {
                try {
                    context.contentResolver.loadThumbnail(song.uri, Size(px, px), null)
                } catch (e: Exception) {
                    null
                }
            }
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }
}

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _glass = MutableStateFlow(prefs.getBoolean("glass", true))
    val glass: StateFlow<Boolean> = _glass

    fun setGlass(value: Boolean) {
        prefs.edit().putBoolean("glass", value).apply()
        _glass.value = value
    }

    private val _accent = MutableStateFlow(prefs.getInt("accent", 0))
    val accent: StateFlow<Int> = _accent

    fun setAccent(index: Int) {
        prefs.edit().putInt("accent", index).apply()
        _accent.value = index
    }

    private val _clear = MutableStateFlow(prefs.getFloat("clear", 0.5f))
    val clear: StateFlow<Float> = _clear

    fun setClear(value: Float) {
        prefs.edit().putFloat("clear", value).apply()
        _clear.value = value
    }

    private val _minSec = MutableStateFlow(prefs.getInt("minSec", 10))
    val minSec: StateFlow<Int> = _minSec

    fun setMinSec(value: Int) {
        prefs.edit().putInt("minSec", value).apply()
        _minSec.value = value
    }

    private val _autoScan = MutableStateFlow(prefs.getBoolean("autoScan", true))
    val autoScan: StateFlow<Boolean> = _autoScan

    fun setAutoScan(value: Boolean) {
        prefs.edit().putBoolean("autoScan", value).apply()
        _autoScan.value = value
    }

    private val _sort = MutableStateFlow(prefs.getInt("sort", 0))
    val sort: StateFlow<Int> = _sort

    fun setSort(value: Int) {
        prefs.edit().putInt("sort", value).apply()
        _sort.value = value
    }

    var scannedBefore: Boolean
        get() = prefs.getBoolean("scanned", false)
        set(value) { prefs.edit().putBoolean("scanned", value).apply() }

    /** Set only after a real sign-in. Accounts need a server, so it is null for now. */
    val userName: String?
        get() = prefs.getString("user", null)
}

data class TopTrack(val title: String, val artist: String?, val count: Int)

data class Stats(
    val listenedMs: Long = 0L,
    val totalPlays: Int = 0,
    val top: List<TopTrack> = emptyList()
)

/** Local listening statistics, stored on the device only. */
class StatsStore(context: Context) {
    private val prefs = context.getSharedPreferences("stats", Context.MODE_PRIVATE)
    private var listened = prefs.getLong("listened", 0L)
    private val plays: JSONObject = try {
        JSONObject(prefs.getString("plays", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }
    private var ticks = 0
    private val _stats = MutableStateFlow(build())
    val stats: StateFlow<Stats> = _stats

    private fun build(): Stats {
        val list = ArrayList<TopTrack>()
        var total = 0
        val keys = plays.keys()
        while (keys.hasNext()) {
            val o = plays.optJSONObject(keys.next()) ?: continue
            val c = o.optInt("c")
            total += c
            list.add(TopTrack(o.optString("t"), o.optString("a").ifBlank { null }, c))
        }
        list.sortByDescending { it.count }
        return Stats(listened, total, list.take(5))
    }

    fun addListening(ms: Long) {
        listened += ms
        _stats.value = _stats.value.copy(listenedMs = listened)
        ticks++
        if (ticks % 20 == 0) flush()
    }

    fun addPlay(song: Song) {
        val key = song.id.toString()
        val o = plays.optJSONObject(key)
            ?: JSONObject().put("t", song.title).put("a", song.artist ?: "").put("c", 0)
        o.put("c", o.optInt("c") + 1)
        plays.put(key, o)
        _stats.value = build()
        flush()
    }

    fun flush() {
        prefs.edit().putLong("listened", listened).putString("plays", plays.toString()).apply()
    }
}

data class Playlist(val id: String, val name: String, val songIds: List<Long>)

/** Favorites and user playlists, stored on the device. */
class LibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("library", Context.MODE_PRIVATE)

    private val _favorites = MutableStateFlow(readFavorites())
    val favorites: StateFlow<Set<Long>> = _favorites

    private val _playlists = MutableStateFlow(readPlaylists())
    val playlists: StateFlow<List<Playlist>> = _playlists

    private fun readFavorites(): Set<Long> = try {
        val arr = JSONArray(prefs.getString("favs", "[]") ?: "[]")
        (0 until arr.length()).map { arr.getLong(it) }.toSet()
    } catch (e: Exception) {
        emptySet()
    }

    private fun readPlaylists(): List<Playlist> = try {
        val arr = JSONArray(prefs.getString("playlists", "[]") ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val songs = o.getJSONArray("songs")
            Playlist(
                o.getString("id"),
                o.getString("name"),
                (0 until songs.length()).map { songs.getLong(it) }
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("songs", JSONArray(p.songIds))
            )
        }
        prefs.edit().putString("playlists", arr.toString()).apply()
        _playlists.value = list
    }

    fun toggleFavorite(songId: Long) {
        val set = _favorites.value.toMutableSet()
        if (!set.add(songId)) set.remove(songId)
        prefs.edit().putString("favs", JSONArray(set.toList()).toString()).apply()
        _favorites.value = set
    }

    fun create(name: String): Playlist {
        val p = Playlist(UUID.randomUUID().toString(), name.trim(), emptyList())
        savePlaylists(_playlists.value + p)
        return p
    }

    fun rename(id: String, name: String) {
        savePlaylists(_playlists.value.map { if (it.id == id) it.copy(name = name.trim()) else it })
    }

    fun delete(id: String) {
        savePlaylists(_playlists.value.filter { it.id != id })
    }

    fun addSong(id: String, songId: Long) {
        savePlaylists(_playlists.value.map {
            if (it.id == id && songId !in it.songIds) it.copy(songIds = it.songIds + songId) else it
        })
    }

    fun removeSong(id: String, songId: Long) {
        savePlaylists(_playlists.value.map {
            if (it.id == id) it.copy(songIds = it.songIds - songId) else it
        })
    }
}
