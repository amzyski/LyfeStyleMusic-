package com.lyfestyle.music

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** A song found on the device through MediaStore. */
data class Song(
    val id: Long,
    val title: String,
    val artist: String?,
    val album: String?,
    val albumId: Long,
    val durationMs: Long
) {
    val uri: Uri
        get() = ContentUris.withAppendedId(
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL), id
        )

    /** Legacy album-art URI, used by the media notification. */
    val artUri: Uri
        get() = ContentUris.withAppendedId(
            Uri.parse("content://media/external/audio/albumart"), albumId
        )
}

/** Scans the device music library. Never returns fake data. */
object MediaScanner {
    private fun clean(s: String?): String? =
        s?.takeIf { it.isNotBlank() && it != MediaStore.UNKNOWN_STRING }

    suspend fun scan(context: Context): List<Song> = withContext(Dispatchers.IO) {
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION
        )
        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val result = ArrayList<Song>()
        val cursor = context.contentResolver.query(collection, projection, selection, null, sort)
            ?: return@withContext result
        cursor.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                result.add(
                    Song(
                        id = c.getLong(idCol),
                        title = clean(c.getString(titleCol)) ?: "—",
                        artist = clean(c.getString(artistCol)),
                        album = clean(c.getString(albumCol)),
                        albumId = c.getLong(albumIdCol),
                        durationMs = c.getLong(durCol)
                    )
                )
            }
        }
        result
    }
}

/** Loads cover art with the system thumbnail API and caches it in memory. */
object ArtworkLoader {
    private val cache = LruCache<String, Bitmap>(80)

    suspend fun load(context: Context, song: Song, px: Int): Bitmap? {
        val key = "${song.id}_$px"
        cache.get(key)?.let { return it }
        val bmp = withContext(Dispatchers.IO) {
            try {
                context.contentResolver.loadThumbnail(song.uri, Size(px, px), null)
            } catch (e: Exception) {
                null
            }
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }
}

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _glass = MutableStateFlow(prefs.getBoolean("glass", true))
    val glass: StateFlow<Boolean> = _glass

    fun setGlass(value: Boolean) {
        prefs.edit().putBoolean("glass", value).apply()
        _glass.value = value
    }

    var scannedBefore: Boolean
        get() = prefs.getBoolean("scanned", false)
        set(value) { prefs.edit().putBoolean("scanned", value).apply() }

    /** Set only after a real sign-in. Accounts need a server, so it is null for now. */
    val userName: String?
        get() = prefs.getString("user", null)
}

data class TopTrack(val title: String, val artist: String?, val count: Int)

data class Stats(
    val listenedMs: Long = 0L,
    val totalPlays: Int = 0,
    val top: List<TopTrack> = emptyList()
)

/** Local listening statistics, stored on the device only. */
class StatsStore(context: Context) {
    private val prefs = context.getSharedPreferences("stats", Context.MODE_PRIVATE)
    private var listened = prefs.getLong("listened", 0L)
    private val plays: JSONObject = try {
        JSONObject(prefs.getString("plays", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }
    private var ticks = 0
    private val _stats = MutableStateFlow(build())
    val stats: StateFlow<Stats> = _stats

    private fun build(): Stats {
        val list = ArrayList<TopTrack>()
        var total = 0
        val keys = plays.keys()
        while (keys.hasNext()) {
            val o = plays.optJSONObject(keys.next()) ?: continue
            val c = o.optInt("c")
            total += c
            list.add(TopTrack(o.optString("t"), o.optString("a").ifBlank { null }, c))
        }
        list.sortByDescending { it.count }
        return Stats(listened, total, list.take(5))
    }

    fun addListening(ms: Long) {
        listened += ms
        _stats.value = _stats.value.copy(listenedMs = listened)
        ticks++
        if (ticks % 20 == 0) flush()
    }

    fun addPlay(song: Song) {
        val key = song.id.toString()
        val o = plays.optJSONObject(key)
            ?: JSONObject().put("t", song.title).put("a", song.artist ?: "").put("c", 0)
        o.put("c", o.optInt("c") + 1)
        plays.put(key, o)
        _stats.value = build()
        flush()
    }

    fun flush() {
        prefs.edit().putLong("listened", listened).putString("plays", plays.toString()).apply()
    }
}
