package com.lyfestyle.music

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface LibraryState {
    data object Idle : LibraryState
    data object Loading : LibraryState
    data class Ready(val songs: List<Song>) : LibraryState
    data class Error(val message: String) : LibraryState
}

data class PlayerUi(
    val current: Song? = null,
    val playing: Boolean = false,
    val position: Long = 0L,
    val duration: Long = 0L,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF
)

private fun Song.toMediaItem(context: Context): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(CoverStore.file(context, id).let { if (it.exists()) Uri.fromFile(it) else artUri })
                .build()
        )
        .build()

class MusicViewModel(app: Application) : AndroidViewModel(app) {
    val settings = SettingsStore(app)
    private val statsStore = StatsStore(app)
    val stats: StateFlow<Stats> = statsStore.stats
    val glass: StateFlow<Boolean> = settings.glass
    val accent: StateFlow<Int> = settings.accent
    val clear: StateFlow<Float> = settings.clear
    val minSec: StateFlow<Int> = settings.minSec
    val autoScan: StateFlow<Boolean> = settings.autoScan
    val sort: StateFlow<Int> = settings.sort

    private val libStore = LibraryStore(app)
    val favorites: StateFlow<Set<Long>> = libStore.favorites
    val playlists: StateFlow<List<Playlist>> = libStore.playlists

    private val _library = MutableStateFlow<LibraryState>(LibraryState.Idle)
    val library = _library.asStateFlow()

    private val _player = MutableStateFlow(PlayerUi())
    val player = _player.asStateFlow()

    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()

    private var controller: MediaController? = null
    private var songMap: Map<String, Song> = emptyMap()

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _player.update { it.copy(playing = isPlaying) }
            if (!isPlaying) statsStore.flush()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            updateCurrent()
            mediaItem?.mediaId?.let { songMap[it] }?.let { statsStore.addPlay(it) }
        }

        override fun onPlaybackStateChanged(playbackState: Int) = updateCurrent()

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _player.update { it.copy(shuffle = shuffleModeEnabled) }
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _player.update { it.copy(repeat = repeatMode) }
        }
    }

    init {
        connect()
        viewModelScope.launch {
            var last = SystemClock.elapsedRealtime()
            while (true) {
                delay(500)
                val now = SystemClock.elapsedRealtime()
                val delta = now - last
                last = now
                val c = controller ?: continue
                if (c.isPlaying) {
                    _player.update { it.copy(position = c.currentPosition) }
                    statsStore.addListening(delta)
                }
            }
        }
    }

    private fun connect() {
        val app = getApplication<Application>()
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                updateCurrent()
                _player.update {
                    it.copy(
                        playing = c.isPlaying,
                        shuffle = c.shuffleModeEnabled,
                        repeat = c.repeatMode
                    )
                }
            } catch (e: Exception) {
                // The service could not be reached; playback controls stay inactive.
            }
        }, ContextCompat.getMainExecutor(app))
    }

    private fun updateCurrent() {
        val c = controller ?: return
        val song = c.currentMediaItem?.mediaId?.let { songMap[it] }
        _player.update {
            it.copy(
                current = song,
                duration = song?.durationMs ?: 0L,
                position = c.currentPosition.coerceAtLeast(0L),
                playing = c.isPlaying
            )
        }
    }

    fun scan() {
        if (_library.value is LibraryState.Loading) return
        _library.value = LibraryState.Loading
        viewModelScope.launch {
            try {
                val list = MediaScanner.scan(getApplication())
                songMap = list.associateBy { it.id.toString() }
                settings.scannedBefore = true
                _library.value = LibraryState.Ready(list)
                updateCurrent()
            } catch (e: Exception) {
                _library.value = LibraryState.Error(e.message ?: "")
            }
        }
    }

    fun setQuery(q: String) {
        _query.value = q
    }

    fun play(song: Song, queue: List<Song>) {
        val c = controller ?: return
        if (_player.value.current?.id == song.id) {
            if (!c.isPlaying) c.play()
            return
        }
        val items = queue.map { it.toMediaItem(getApplication<Application>()) }
        val index = queue.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
    }

    fun queueSongs(): List<Song> {
        val c = controller ?: return emptyList()
        return (0 until c.mediaItemCount).mapNotNull { songMap[c.getMediaItemAt(it).mediaId] }
    }

    fun skipTo(index: Int) {
        controller?.let {
            it.seekTo(index, 0L)
            it.play()
        }
    }

    fun setSort(value: Int) = settings.setSort(value)

    fun playNext(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            play(song, listOf(song))
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem(getApplication<Application>()))
        }
    }

    fun addToQueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            play(song, listOf(song))
        } else {
            c.addMediaItem(song.toMediaItem(getApplication<Application>()))
        }
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 3000) c.seekTo(0) else c.seekToPreviousMediaItem()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        _player.update { it.copy(position = ms) }
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun setGlass(enabled: Boolean) = settings.setGlass(enabled)
    fun setAccent(index: Int) = settings.setAccent(index)
    fun setClear(value: Float) = settings.setClear(value)
    fun setAutoScan(value: Boolean) = settings.setAutoScan(value)

    fun setMinSec(value: Int) {
        settings.setMinSec(value)
        if (_library.value !is LibraryState.Idle) scan()
    }

    fun resetCovers() = CoverStore.clearAll(getApplication<Application>())

    fun toggleFavorite(songId: Long) = libStore.toggleFavorite(songId)
    fun createPlaylist(name: String): Playlist = libStore.create(name)
    fun renamePlaylist(id: String, name: String) = libStore.rename(id, name)
    fun deletePlaylist(id: String) = libStore.delete(id)
    fun addToPlaylist(id: String, songId: Long) = libStore.addSong(id, songId)
    fun removeFromPlaylist(id: String, songId: Long) = libStore.removeSong(id, songId)

    fun setCover(song: Song, uri: Uri) {
        viewModelScope.launch { CoverStore.save(getApplication<Application>(), song.id, uri) }
    }

    fun resetCover(song: Song) = CoverStore.remove(getApplication<Application>(), song.id)

    fun playShuffled(queue: List<Song>) {
        val c = controller ?: return
        if (queue.isEmpty()) return
        c.shuffleModeEnabled = true
        c.setMediaItems(queue.map { it.toMediaItem(getApplication<Application>()) }, queue.indices.random(), 0L)
        c.prepare()
        c.play()
    }

    override fun onCleared() {
        statsStore.flush()
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
