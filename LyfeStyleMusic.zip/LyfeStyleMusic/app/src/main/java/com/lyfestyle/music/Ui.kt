package com.lyfestyle.music

import android.graphics.Bitmap
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

val Accent = Color(0xFFFFE600)

/** True when the Liquid Glass look is enabled in settings. */
val LocalGlass = compositionLocalOf { true }

@Composable
fun LyfeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.Black,
            background = Color.Black,
            onBackground = Color.White,
            surface = Color(0xFF0E0E0E),
            onSurface = Color.White
        ),
        content = content
    )
}

/** Soft spring "squish" when a control is pressed. */
fun Modifier.pressScale(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = source,
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
}

/**
 * Liquid Glass surface: dark translucent body, light gradient, top specular highlight
 * and a bright rim. Falls back to a flat dark surface when glass is turned off.
 */
@Composable
fun Glass(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val glass = LocalGlass.current
    val base = if (glass) {
        modifier
            .clip(shape)
            .background(Color.Black.copy(alpha = 0.50f))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.20f),
                        Color.White.copy(alpha = 0.04f),
                        Color.White.copy(alpha = 0.12f)
                    )
                )
            )
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        0f to Color.White.copy(alpha = 0.18f),
                        0.4f to Color.Transparent
                    )
                )
            }
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.60f),
                        Color.White.copy(alpha = 0.06f),
                        Color.White.copy(alpha = 0.35f)
                    )
                ),
                shape
            )
    } else {
        modifier
            .clip(shape)
            .background(Color(0xFF141414))
            .border(1.dp, Color(0xFF2B2B2B), shape)
    }
    Box(base, content = content)
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** Cover art loaded from the device; shows a note icon when there is no cover. */
@Composable
fun Artwork(
    song: Song?,
    modifier: Modifier = Modifier,
    px: Int = 256,
    shape: Shape = RoundedCornerShape(12.dp)
) {
    val context = LocalContext.current
    val bmp by produceState<Bitmap?>(null, song?.id, px) {
        value = if (song == null) null else ArtworkLoader.load(context, song, px)
    }
    Box(
        modifier
            .clip(shape)
            .background(Color(0xFF1A1A1A)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Color.White.copy(alpha = 0.35f))
        }
    }
}

/** Heavily blurred cover used as an ambient background. */
@Composable
fun BlurBackdrop(song: Song?, alpha: Float) {
    val context = LocalContext.current
    val bmp by produceState<Bitmap?>(null, song?.id) {
        value = song?.let { ArtworkLoader.load(context, it, 256) }
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alpha = alpha,
            modifier = Modifier
                .fillMaxSize()
                .blur(80.dp)
        )
    }
}
