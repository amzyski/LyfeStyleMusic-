package com.lyfestyle.music

import android.graphics.Bitmap
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.toIntSize

/** Colour themes in the style of the LUH SHMUNK site: dark base + neon accent + soft glow. */
data class Palette(
    val name: String,
    val accent: Color,
    val glowA: Color,
    val glowB: Color,
    val base: Color
)

val Palettes = listOf(
    Palette("Purple", Color(0xFFB07CFF), Color(0xFF5B21B6), Color(0xFF3B0A6E), Color(0xFF020106)),
    Palette("Luh Green", Color(0xFF7BF08C), Color(0xFF1FA86B), Color(0xFF2C5A3A), Color(0xFF000000)),
    Palette("Ice", Color(0xFF7FD6FF), Color(0xFF1F7FD4), Color(0xFF0E3A5E), Color(0xFF000000)),
    Palette("Sunset", Color(0xFFFFA45C), Color(0xFFD4521F), Color(0xFF5E1E2A), Color(0xFF000000)),
    Palette("Lemon", Color(0xFFFFE600), Color(0xFF8A7A00), Color(0xFF4A3F00), Color(0xFF000000))
)

val LocalPalette = compositionLocalOf { Palettes[0] }

/** True when the Liquid Glass look is enabled in settings. */
val LocalGlass = compositionLocalOf { true }

/** 0 = denser glass, 1 = most transparent glass. */
val LocalGlassClear = compositionLocalOf { 0.5f }

/** Opens the "song options" menu (favorite, playlist, cover). */
val LocalAddToPlaylist = compositionLocalOf<(Song) -> Unit> { {} }

val LocalOpenSongMenu = compositionLocalOf<(Song) -> Unit> { {} }

val Accent: Color
    @Composable get() = LocalPalette.current.accent

@Composable
fun LyfeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.Black,
            background = Color.Black,
            onBackground = Color.White,
            surface = Color(0xFF0E0E0E),
            onSurface = Color.White
        ),
        content = content
    )
}

/** Soft spring "squish" when a control is pressed. */
fun Modifier.pressScale(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = source,
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
}

/**
 * Liquid Glass surface: translucent body tinted with the accent colour, specular
 * highlight on top, soft glow in the corner, bright rim light and a depth shadow.
 * Falls back to a flat dark surface when glass is turned off.
 */
@Composable
fun Glass(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    rimAlpha: Float = 0.75f,
    rimColor: Color? = null,
    backdropRadius: Dp? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val glass = LocalGlass.current
    val clear = LocalGlassClear.current
    val accent = LocalPalette.current.accent
    val backdrop = LocalBackdrop.current
    val density = LocalDensity.current
    val key = remember { Any() }
    val real = glass && backdropRadius != null
    if (real) {
        DisposableEffect(key) { onDispose { backdrop.regions.remove(key) } }
    }
    val rim = rimColor ?: Color.White
    val fill = 0.07f + 0.10f * (1f - clear)
    val base = if (glass) {
        // With a real blurred backdrop the glass only needs a light tint on top of it.
        val tracked = if (real) {
            val radiusPx = with(density) { backdropRadius!!.toPx() }
            modifier.onGloballyPositioned {
                backdrop.regions[key] = GlassRegion(it.boundsInWindow(), radiusPx)
            }
        } else modifier
        tracked
            .shadow(
                elevation = 16.dp,
                shape = shape,
                clip = false,
                ambientColor = accent.copy(alpha = 0.20f),
                spotColor = Color.Black
            )
            .clip(shape)
            .background(Color.Black.copy(alpha = if (real) 0.22f else 0.62f - 0.45f * clear))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = fill + 0.05f),
                        Color.White.copy(alpha = fill * 0.35f)
                    )
                )
            )
            .background(
                Brush.linearGradient(
                    listOf(
                        accent.copy(alpha = 0.16f),
                        Color.Transparent,
                        accent.copy(alpha = 0.10f)
                    )
                )
            )
            .drawBehind {
                // specular highlight along the top edge
                drawRect(
                    Brush.verticalGradient(
                        0f to Color.White.copy(alpha = 0.30f),
                        0.30f to Color.Transparent
                    )
                )
                // soft coloured glow in the lower corner
                drawRect(
                    Brush.radialGradient(
                        listOf(accent.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width, size.height),
                        radius = size.maxDimension * 0.7f
                    )
                )
            }
            .border(
                1.2.dp,
                Brush.linearGradient(
                    listOf(
                        rim.copy(alpha = rimAlpha),
                        rim.copy(alpha = rimAlpha * 0.08f),
                        accent.copy(alpha = rimAlpha * 0.7f)
                    )
                ),
                shape
            )
    } else {
        modifier
            .clip(shape)
            .background(Color(0xFF141414))
            .border(1.dp, Color(0xFF2B2B2B), shape)
    }
    Box(base, content = content)
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** Cover art: the user's own cover, or the one from the file; note icon if none. */
@Composable
fun Artwork(
    song: Song?,
    modifier: Modifier = Modifier,
    px: Int = 256,
    shape: Shape = RoundedCornerShape(12.dp),
    depth: Boolean = false
) {
    val context = LocalContext.current
    val accent = LocalPalette.current.accent
    val version by CoverStore.version.collectAsState()
    val bmp by produceState<Bitmap?>(null, song?.id, px, version) {
        value = if (song == null) null else ArtworkLoader.load(context, song, px)
    }
    // "depth" = soft shadow, glossy rim and a light sheen, so covers look three-dimensional
    val base = if (depth) {
        modifier.shadow(
            elevation = 10.dp,
            shape = shape,
            clip = false,
            ambientColor = accent.copy(alpha = 0.35f),
            spotColor = Color.Black
        )
    } else modifier
    Box(
        base
            .clip(shape)
            .background(Color(0xFF1A1A1A))
            .then(
                if (depth) Modifier.border(
                    1.dp,
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.45f), Color.White.copy(alpha = 0.04f))
                    ),
                    shape
                ) else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Color.White.copy(alpha = 0.35f))
        }
        if (depth) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color.White.copy(alpha = 0.12f),
                            0.4f to Color.Transparent
                        )
                    )
            )
        }
    }
}

/** Heavily blurred cover used as an ambient background. */
@Composable
fun BlurBackdrop(song: Song?, alpha: Float) {
    val context = LocalContext.current
    val version by CoverStore.version.collectAsState()
    val bmp by produceState<Bitmap?>(null, song?.id, version) {
        value = song?.let { ArtworkLoader.load(context, it, 256) }
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alpha = alpha,
            modifier = Modifier
                .fillMaxSize()
                .blur(80.dp)
        )
    }
}

/** App background: dark base with coloured glow, like the website. */
@Composable
fun AppBackground(song: Song?) {
    val p = LocalPalette.current
    Box(
        Modifier
            .fillMaxSize()
            .background(p.base)
            .drawBehind {
                val w = size.width
                val h = size.height
                val wave = Path().apply {
                    moveTo(0f, h * 0.10f)
                    cubicTo(w * 0.35f, 0f, w * 0.60f, h * 0.22f, w, h * 0.08f)
                    lineTo(w, 0f)
                    lineTo(0f, 0f)
                    close()
                }
                drawPath(
                    wave,
                    Brush.linearGradient(
                        listOf(p.glowA.copy(alpha = 0.24f), Color.Transparent),
                        start = Offset(0f, 0f),
                        end = Offset(w, h * 0.3f)
                    )
                )
                val wave2 = Path().apply {
                    moveTo(w, h * 0.35f)
                    cubicTo(w * 0.70f, h * 0.45f, w * 0.85f, h * 0.70f, w * 0.45f, h * 0.90f)
                    lineTo(w, h * 0.90f)
                    close()
                }
                drawPath(
                    wave2,
                    Brush.radialGradient(
                        listOf(p.glowB.copy(alpha = 0.24f), Color.Transparent),
                        center = Offset(w, h * 0.6f),
                        radius = h * 0.5f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(p.glowA.copy(alpha = 0.18f), Color.Transparent),
                        center = Offset(w * 0.15f, h * 0.05f),
                        radius = size.maxDimension * 0.75f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(p.glowB.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(w * 0.95f, h * 0.45f),
                        radius = size.maxDimension * 0.70f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(p.glowA.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(w * 0.20f, h * 0.98f),
                        radius = size.maxDimension * 0.70f
                    )
                )
            }
    )
    if (LocalGlass.current) BlurBackdrop(song, 0.06f)
}

/** Height of the top bar (status bar + title row). Content under it fades out. */
val LocalTopInset = compositionLocalOf { 0.dp }

/** Covers of the songs that currently scroll under the top and bottom bars. */
class GlowState {
    var top by mutableStateOf<List<Song>>(emptyList())
    var bottom by mutableStateOf<List<Song>>(emptyList())
}

val LocalGlow = compositionLocalOf { GlowState() }

/** Fades the content out towards the top edge (used under the transparent top bar). */
fun Modifier.fadeTop(px: Float): Modifier = this
    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    .drawWithContent {
        drawContent()
        drawRect(
            Brush.verticalGradient(
                0f to Color.Transparent,
                1f to Color.Black,
                startY = 0f,
                endY = px
            ),
            blendMode = BlendMode.DstIn
        )
    }

/** Soft blurred light made from the covers of the tracks that went under a bar. */
@Composable
fun GlowStrip(songs: List<Song>, fromTop: Boolean, modifier: Modifier = Modifier) {
    if (songs.isEmpty() || !LocalGlass.current) return
    Row(
        modifier
            .graphicsLayer {
                compositingStrategy = CompositingStrategy.Offscreen
                alpha = 0.6f
            }
            .drawWithContent {
                drawContent()
                drawRect(
                    Brush.verticalGradient(
                        if (fromTop) listOf(Color.Black, Color.Transparent)
                        else listOf(Color.Transparent, Color.Black)
                    ),
                    blendMode = BlendMode.DstIn
                )
            }
            .blur(36.dp)
    ) {
        songs.forEach { s ->
            Artwork(s, Modifier.weight(1f).fillMaxHeight(), 96, RectangleShape)
        }
    }
}

/** Thin slider with a round thumb (no vertical handle). */
@Composable
fun GlassSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    thumb: Boolean = true,
    onFinished: () -> Unit = {}
) {
    val change by rememberUpdatedState(onValueChange)
    val finished by rememberUpdatedState(onFinished)
    val range = valueRange.endInclusive - valueRange.start
    Box(
        modifier
            .height(28.dp)
            .pointerInput(valueRange) {
                detectTapGestures { pos ->
                    val f = (pos.x / size.width).coerceIn(0f, 1f)
                    change(valueRange.start + f * range)
                    finished()
                }
            }
            .pointerInput(valueRange) {
                detectHorizontalDragGestures(
                    onDragStart = { pos ->
                        change(valueRange.start + (pos.x / size.width).coerceIn(0f, 1f) * range)
                    },
                    onDragEnd = { finished() },
                    onDragCancel = { finished() },
                    onHorizontalDrag = { c, _ ->
                        change(valueRange.start + (c.position.x / size.width).coerceIn(0f, 1f) * range)
                    }
                )
            }
            .drawBehind {
                val f = if (range <= 0f) 0f else ((value - valueRange.start) / range).coerceIn(0f, 1f)
                val h = 6.dp.toPx()
                val cy = size.height / 2
                drawRoundRect(
                    color.copy(alpha = 0.22f),
                    topLeft = Offset(0f, cy - h / 2),
                    size = Size(size.width, h),
                    cornerRadius = CornerRadius(h / 2)
                )
                drawRoundRect(
                    color,
                    topLeft = Offset(0f, cy - h / 2),
                    size = Size(size.width * f, h),
                    cornerRadius = CornerRadius(h / 2)
                )
                if (thumb) drawCircle(color, radius = 8.dp.toPx(), center = Offset(size.width * f, cy))
            }
    )
}

/** Round translucent button used in the player (close, more, favorite). */
@Composable
fun CircleButton(
    icon: ImageVector,
    description: String?,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Glass(modifier.size(size).pressScale(onClick = onClick), CircleShape, rimAlpha = 0.2f) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(icon, description, tint = tint)
        }
    }
}

/** Where a glass panel sits on the screen: its content shows a blurred copy of what is behind it. */
class GlassRegion(val rect: Rect, val radius: Float)

class BackdropState {
    val regions = mutableStateMapOf<Any, GlassRegion>()
}

val LocalBackdrop = compositionLocalOf { BackdropState() }

/**
 * Marks the content that glass panels should blur. The content is recorded into a layer,
 * drawn normally, and then a blurred copy of it is drawn inside each registered glass panel.
 */
fun Modifier.backdropSource(state: BackdropState, enabled: Boolean): Modifier = composed {
    if (!enabled) {
        this
    } else {
        val density = LocalDensity.current
        val content = rememberGraphicsLayer()
        val blur = rememberGraphicsLayer()
        val effect = remember(density) {
            val r = with(density) { 22.dp.toPx() }
            BlurEffect(r, r, TileMode.Clamp)
        }
        this.drawWithContent {
            content.record(this, layoutDirection, size.toIntSize()) {
                this@drawWithContent.drawContent()
            }
            drawLayer(content)
            if (state.regions.isNotEmpty()) {
                blur.renderEffect = effect
                blur.record(this, layoutDirection, size.toIntSize()) {
                    drawLayer(content)
                }
                state.regions.values.forEach { r ->
                    val path = Path().apply {
                        addRoundRect(RoundRect(r.rect, CornerRadius(r.radius, r.radius)))
                    }
                    clipPath(path) { drawLayer(blur) }
                }
            }
        }
    }
}
