package com.lyfestyle.music

import android.graphics.Bitmap
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/** Colour themes in the style of the LUH SHMUNK site: dark base + neon accent + soft glow. */
data class Palette(
    val name: String,
    val accent: Color,
    val glowA: Color,
    val glowB: Color,
    val base: Color
)

val Palettes = listOf(
    Palette("Luh Green", Color(0xFF7BF08C), Color(0xFF1FA86B), Color(0xFF2C5A3A), Color(0xFF030A06)),
    Palette("Violet", Color(0xFFC4A0FF), Color(0xFF6B3FD4), Color(0xFF2A1A5E), Color(0xFF07050D)),
    Palette("Ice", Color(0xFF7FD6FF), Color(0xFF1F7FD4), Color(0xFF0E3A5E), Color(0xFF040A10)),
    Palette("Sunset", Color(0xFFFFA45C), Color(0xFFD4521F), Color(0xFF5E1E2A), Color(0xFF0D0605)),
    Palette("Lemon", Color(0xFFFFE600), Color(0xFF8A7A00), Color(0xFF4A3F00), Color(0xFF0A0900))
)

val LocalPalette = compositionLocalOf { Palettes[0] }

/** True when the Liquid Glass look is enabled in settings. */
val LocalGlass = compositionLocalOf { true }

/** 0 = denser glass, 1 = most transparent glass. */
val LocalGlassClear = compositionLocalOf { 0.25f }

/** Opens the "song options" menu (favorite, playlist, cover). */
val LocalOpenSongMenu = compositionLocalOf<(Song) -> Unit> { {} }

val Accent: Color
    @Composable get() = LocalPalette.current.accent

@Composable
fun LyfeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.Black,
            background = Color.Black,
            onBackground = Color.White,
            surface = Color(0xFF0E0E0E),
            onSurface = Color.White
        ),
        content = content
    )
}

/** Soft spring "squish" when a control is pressed. */
fun Modifier.pressScale(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = source,
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
}

/**
 * Liquid Glass surface: translucent body tinted with the accent colour, specular
 * highlight on top, soft glow in the corner, bright rim light and a depth shadow.
 * Falls back to a flat dark surface when glass is turned off.
 */
@Composable
fun Glass(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val glass = LocalGlass.current
    val clear = LocalGlassClear.current
    val accent = LocalPalette.current.accent
    val baseAlpha = 0.62f - 0.5f * clear
    val base = if (glass) {
        modifier
            .shadow(
                elevation = 14.dp,
                shape = shape,
                clip = false,
                ambientColor = accent.copy(alpha = 0.25f),
                spotColor = Color.Black
            )
            .clip(shape)
            .background(Color.Black.copy(alpha = baseAlpha))
            .background(
                Brush.linearGradient(
                    listOf(
                        accent.copy(alpha = 0.18f),
                        Color.White.copy(alpha = 0.05f),
                        accent.copy(alpha = 0.10f)
                    )
                )
            )
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        0f to Color.White.copy(alpha = 0.22f),
                        0.35f to Color.Transparent
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(accent.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width, size.height),
                        radius = size.maxDimension * 0.7f
                    )
                )
            }
            .border(
                1.2.dp,
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.75f),
                        Color.White.copy(alpha = 0.05f),
                        accent.copy(alpha = 0.55f)
                    )
                ),
                shape
            )
    } else {
        modifier
            .clip(shape)
            .background(Color(0xFF141414))
            .border(1.dp, Color(0xFF2B2B2B), shape)
    }
    Box(base, content = content)
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** Cover art: the user's own cover, or the one from the file; note icon if none. */
@Composable
fun Artwork(
    song: Song?,
    modifier: Modifier = Modifier,
    px: Int = 256,
    shape: Shape = RoundedCornerShape(12.dp)
) {
    val context = LocalContext.current
    val version by CoverStore.version.collectAsState()
    val bmp by produceState<Bitmap?>(null, song?.id, px, version) {
        value = if (song == null) null else ArtworkLoader.load(context, song, px)
    }
    Box(
        modifier
            .clip(shape)
            .background(Color(0xFF1A1A1A)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Color.White.copy(alpha = 0.35f))
        }
    }
}

/** Heavily blurred cover used as an ambient background. */
@Composable
fun BlurBackdrop(song: Song?, alpha: Float) {
    val context = LocalContext.current
    val version by CoverStore.version.collectAsState()
    val bmp by produceState<Bitmap?>(null, song?.id, version) {
        value = song?.let { ArtworkLoader.load(context, it, 256) }
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alpha = alpha,
            modifier = Modifier
                .fillMaxSize()
                .blur(80.dp)
        )
    }
}

/** App background: dark base with coloured glow, like the website. */
@Composable
fun AppBackground(song: Song?) {
    val p = LocalPalette.current
    Box(
        Modifier
            .fillMaxSize()
            .background(p.base)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(p.glowA.copy(alpha = 0.55f), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.05f),
                        radius = size.maxDimension * 0.75f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(p.glowB.copy(alpha = 0.60f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.45f),
                        radius = size.maxDimension * 0.70f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(p.glowA.copy(alpha = 0.35f), Color.Transparent),
                        center = Offset(size.width * 0.20f, size.height * 0.98f),
                        radius = size.maxDimension * 0.70f
                    )
                )
            }
    )
    if (LocalGlass.current) BlurBackdrop(song, 0.22f)
}
