package com.lyfestyle.music

import android.Manifest
import android.app.LocaleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.LocaleList
import androidx.activity.compose.BackHandler
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class MainTab { Library, Playlists, Profile, Search }

fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

fun setAppLanguage(context: Context, tag: String) {
    val manager = context.getSystemService(LocaleManager::class.java)
    manager.applicationLocales = LocaleList.forLanguageTags(tag)
}

// ───────────────────────── Root ─────────────────────────

@Composable
fun AppRoot(vm: MusicViewModel) {
    val glass by vm.glass.collectAsStateWithLifecycle()
    val accentIdx by vm.accent.collectAsStateWithLifecycle()
    val clear by vm.clear.collectAsStateWithLifecycle()
    CompositionLocalProvider(
        LocalGlass provides glass,
        LocalGlassClear provides clear,
        LocalPalette provides Palettes[accentIdx.coerceIn(0, Palettes.lastIndex)]
    ) {
        MainScaffold(vm)
    }
}


@Composable
fun MainScaffold(vm: MusicViewModel) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(MainTab.Library) }
    var playerOpen by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var selectedPlaylist by rememberSaveable { mutableStateOf<String?>(null) }
    var menuSong by remember { mutableStateOf<Song?>(null) }
    var pickerSong by remember { mutableStateOf<Song?>(null) }
    var coverTarget by remember { mutableStateOf<Song?>(null) }
    val ui by vm.player.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()
    val allSongs = (library as? LibraryState.Ready)?.songs ?: emptyList()
    val glow = remember { GlowState() }
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 64.dp

    val coverPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val target = coverTarget
        if (uri != null && target != null) vm.setCover(target, uri)
        coverTarget = null
    }

    LaunchedEffect(Unit) {
        if (vm.autoScan.value && vm.settings.scannedBefore && hasAudioPermission(context) &&
            vm.library.value is LibraryState.Idle
        ) vm.scan()
    }

    BackHandler(enabled = playerOpen) { playerOpen = false }
    BackHandler(enabled = !playerOpen && tab == MainTab.Playlists && selectedPlaylist != null) {
        selectedPlaylist = null
    }

    CompositionLocalProvider(
        LocalOpenSongMenu provides { song: Song -> menuSong = song },
        LocalGlow provides glow,
        LocalTopInset provides topInset,
        LocalAddToPlaylist provides { song: Song -> pickerSong = song }
    ) {
        Box(Modifier.fillMaxSize()) {
            AppBackground(ui.current)

            AnimatedContent(
                targetState = tab,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = {
                    (fadeIn(tween(320)) + scaleIn(initialScale = 0.96f, animationSpec = tween(320))) togetherWith
                        fadeOut(tween(180))
                },
                label = "tab"
            ) { t ->
                when (t) {
                    MainTab.Library -> LibraryScreen(vm)
                    MainTab.Playlists -> Box(Modifier.padding(top = topInset)) {
                        PlaylistsScreen(vm, allSongs, selectedPlaylist) { selectedPlaylist = it }
                    }
                    MainTab.Profile -> Box(Modifier.padding(top = topInset)) {
                        ProfileScreen(vm, showSettings) { showSettings = it }
                    }
                    MainTab.Search -> Box(Modifier.padding(top = topInset)) { SearchScreen(vm) }
                }
            }

            // Transparent top bar: tracks scroll under it and leave a blurred light
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(topInset + 24.dp)
                    .background(
                        Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.75f), Color.Transparent))
                    )
            )
            GlowStrip(
                glow.top, true,
                Modifier.align(Alignment.TopCenter).fillMaxWidth().height(topInset + 24.dp)
            )
            TopBar(vm.settings.userName, Modifier.align(Alignment.TopCenter)) {
                tab = MainTab.Profile
                showSettings = false
            }

            GlowStrip(
                glow.bottom, false,
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(190.dp)
            )
            Column(
                Modifier.align(Alignment.BottomCenter)
            ) {
                if (ui.current != null) {
                    MiniPlayer(vm, ui) { playerOpen = true }
                    Spacer(Modifier.height(8.dp))
                }
                BottomBar(tab) {
                    tab = it
                    if (it != MainTab.Profile) showSettings = false
                    if (it != MainTab.Playlists) selectedPlaylist = null
                }
            }

            AnimatedVisibility(
                visible = playerOpen && ui.current != null,
                enter = slideInVertically(tween(450, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300)),
                exit = slideOutVertically(tween(350)) { it } + fadeOut(tween(250))
            ) {
                PlayerScreen(vm) { playerOpen = false }
            }
        }
    }

    menuSong?.let { s ->
        SongMenuDialog(
            song = s,
            vm = vm,
            onDismiss = { menuSong = null },
            onPickCover = {
                coverTarget = it
                coverPicker.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onAddToPlaylist = { pickerSong = it }
        )
    }
    pickerSong?.let { s -> PlaylistPickerDialog(s, vm) { pickerSong = null } }
}

// ───────────────────────── Bars ─────────────────────────

@Composable
fun TopBar(userName: String?, modifier: Modifier = Modifier, onAvatar: () -> Unit) {
    val accent = Accent
    val title = buildAnnotatedString {
        append("LyfeStyle ")
        withStyle(SpanStyle(color = accent)) { append("Music") }
    }
    Row(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(64.dp)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            title,
            style = TextStyle(
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                fontStyle = FontStyle.Italic
            ),
            maxLines = 1
        )
        Glass(
            Modifier.size(46.dp).pressScale(onClick = onAvatar),
            CircleShape,
            rimAlpha = 1f,
            rimColor = accent
        ) {
            if (userName != null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        userName.take(1).uppercase(), color = Color.White,
                        fontWeight = FontWeight.Bold, fontSize = 18.sp
                    )
                }
            } else {
                Image(
                    painter = painterResource(R.drawable.avatar_logo),
                    contentDescription = stringResource(R.string.profile),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
fun BottomBar(tab: MainTab, onTab: (MainTab) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .background(p.base.copy(alpha = 0.92f))
            .drawBehind {
                drawLine(
                    Color.White.copy(alpha = 0.08f),
                    Offset(0f, 0f),
                    Offset(size.width, 0f),
                    strokeWidth = 1.dp.toPx()
                )
            }
            .navigationBarsPadding()
            .padding(top = 8.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        BarItem(Modifier.weight(1f), Icons.Rounded.LibraryMusic, R.string.library, tab == MainTab.Library) {
            onTab(MainTab.Library)
        }
        BarItem(Modifier.weight(1f), Icons.Rounded.Album, R.string.playlists, tab == MainTab.Playlists) {
            onTab(MainTab.Playlists)
        }
        BarItem(Modifier.weight(1f), Icons.Rounded.Person, R.string.profile, tab == MainTab.Profile) {
            onTab(MainTab.Profile)
        }
        BarItem(Modifier.weight(1f), Icons.Rounded.Search, R.string.search, tab == MainTab.Search) {
            onTab(MainTab.Search)
        }
    }
}

@Composable
private fun BarItem(
    modifier: Modifier,
    icon: ImageVector,
    label: Int,
    selected: Boolean,
    onClick: () -> Unit
) {
    val color = if (selected) Accent else Color.White.copy(alpha = 0.6f)
    Column(
        modifier.pressScale(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(2.dp))
        Text(
            stringResource(label), color = color, fontSize = 12.sp,
            fontWeight = FontWeight.Medium, maxLines = 1
        )
    }
}

// ───────────────────────── Library ─────────────────────────

@Composable
fun LibraryScreen(vm: MusicViewModel) {
    val state by vm.library.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var denied by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasAudioPermission(context)) {
            denied = false
            vm.scan()
        } else {
            denied = true
        }
    }
    val start: () -> Unit = {
        val need = listOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            .filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) vm.scan() else launcher.launch(need.toTypedArray())
    }

    when (val s = state) {
        LibraryState.Idle ->
            if (denied) {
                PermissionDenied(onGrant = start, onSettings = {
                    context.startActivity(
                        Intent(
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", context.packageName, null)
                        )
                    )
                })
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    FindMusicButton(start)
                }
            }

        LibraryState.Loading ->
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(color = Accent)
                Spacer(Modifier.height(16.dp))
                Text(stringResource(R.string.scanning), color = Color.White.copy(alpha = 0.7f))
            }

        is LibraryState.Error ->
            MessageBlock(
                stringResource(R.string.scan_error), s.message,
                stringResource(R.string.retry), start
            )

        is LibraryState.Ready ->
            if (s.songs.isEmpty()) {
                MessageBlock(
                    stringResource(R.string.empty_title), stringResource(R.string.empty_text),
                    stringResource(R.string.rescan), start
                )
            } else {
                LibraryList(vm, s.songs)
            }
    }
}

@Composable
fun FindMusicButton(onClick: () -> Unit) {
    Glass(Modifier.padding(24.dp).pressScale(onClick = onClick), RoundedCornerShape(36.dp)) {
        Row(
            Modifier.padding(horizontal = 28.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.LibraryMusic, null, tint = Accent)
            Spacer(Modifier.width(12.dp))
            Text(
                stringResource(R.string.find_music), color = Color.White,
                fontSize = 18.sp, fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun PillButton(text: String, modifier: Modifier = Modifier, filled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Box(
        modifier
            .height(52.dp)
            .pressScale(onClick = onClick)
            .clip(shape)
            .background(if (filled) Accent else Color.White.copy(alpha = 0.10f))
            .border(1.dp, if (filled) Accent else Color.White.copy(alpha = 0.25f), shape)
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = if (filled) Color.Black else Color.White,
            fontWeight = FontWeight.SemiBold, fontSize = 16.sp
        )
    }
}

@Composable
fun MessageBlock(title: String, text: String, button: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        if (text.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(text, color = Color.White.copy(alpha = 0.6f), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
        PillButton(button, onClick = onClick)
    }
}

@Composable
fun PermissionDenied(onGrant: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            stringResource(R.string.permission_title), color = Color.White, fontSize = 22.sp,
            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.permission_text), color = Color.White.copy(alpha = 0.6f),
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        PillButton(stringResource(R.string.grant), onClick = onGrant)
        Spacer(Modifier.height(12.dp))
        PillButton(stringResource(R.string.open_settings), filled = false, onClick = onSettings)
    }
}

@Composable
fun LibraryList(vm: MusicViewModel, songs: List<Song>) {
    SongsLazyList(
        vm, songs,
        underBar = true,
        header = {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    stringResource(R.string.songs_count, songs.size),
                    color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp
                )
                Box(
                    Modifier.size(40.dp).pressScale(onClick = { vm.scan() }),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Rounded.Refresh, stringResource(R.string.rescan),
                        tint = Accent, modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    )
}

@Composable
fun SearchField(query: String, focus: FocusRequester, onChange: (String) -> Unit) {
    Glass(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(52.dp),
        RoundedCornerShape(26.dp)
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Search, null, tint = Color.White.copy(alpha = 0.6f))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(stringResource(R.string.search_hint), color = Color.White.copy(alpha = 0.45f))
                }
                BasicTextField(
                    value = query,
                    onValueChange = onChange,
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Accent),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus)
                )
            }
            if (query.isNotEmpty()) {
                Box(Modifier.size(32.dp).pressScale(onClick = { onChange("") }), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Close, stringResource(R.string.close), tint = Color.White.copy(alpha = 0.7f))
                }
            }
        }
    }
}

@Composable
fun SongRow(
    song: Song,
    current: Boolean,
    favorite: Boolean,
    onRemove: (() -> Unit)?,
    onClick: () -> Unit
) {
    val openMenu = LocalOpenSongMenu.current
    Row(
        Modifier.fillMaxWidth().pressScale(onClick = onClick).padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(song, Modifier.size(66.dp), 192, RoundedCornerShape(16.dp), depth = true)
        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            Text(
                song.title, color = if (current) Accent else Color.White,
                fontWeight = FontWeight.Medium, fontSize = 19.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            val sub = listOfNotNull(song.artist, song.album).joinToString(" · ")
            if (sub.isNotEmpty()) {
                Text(
                    sub, color = Color.White.copy(alpha = 0.5f), fontSize = 15.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (favorite) {
            Icon(Icons.Rounded.Star, null, tint = Accent, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(formatTime(song.durationMs), color = Color.White.copy(alpha = 0.5f), fontSize = 15.sp)
        if (onRemove != null) {
            Box(Modifier.size(36.dp).pressScale(onClick = onRemove), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Close, stringResource(R.string.remove_from_list), tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(20.dp))
            }
        }
        Box(Modifier.size(40.dp).pressScale(onClick = { openMenu(song) }), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.MoreVert, stringResource(R.string.more), tint = Accent)
        }
    }
}

// ───────────────────────── Profile ─────────────────────────

@Composable
fun ProfileScreen(vm: MusicViewModel, showSettings: Boolean, setShowSettings: (Boolean) -> Unit) {
    var auth by remember { mutableStateOf<String?>(null) }
    val userName = vm.settings.userName

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 200.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(8.dp))
        Glass(Modifier.size(104.dp), CircleShape) {
            if (userName != null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(userName.take(1).uppercase(), color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Image(
                    painter = painterResource(R.drawable.avatar_logo),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            userName ?: stringResource(R.string.guest), color = Color.White,
            fontSize = 24.sp, fontWeight = FontWeight.Bold
        )
        if (userName == null) {
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.local_mode), color = Color.White.copy(alpha = 0.55f),
                fontSize = 13.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PillButton(stringResource(R.string.sign_in), Modifier.weight(1f)) { auth = "in" }
                PillButton(stringResource(R.string.sign_up), Modifier.weight(1f), filled = false) { auth = "up" }
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(
            stringResource(R.string.advanced_settings), color = Color.White, fontSize = 20.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        SettingsContent(vm)
    }

    auth?.let { mode -> AuthDialog(signUp = mode == "up") { auth = null } }
}

@Composable
fun StatTile(modifier: Modifier, value: String, label: String) {
    Glass(modifier, RoundedCornerShape(20.dp)) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text(label, color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun GlassField(value: String, onChange: (String) -> Unit, hint: String, password: Boolean = false) {
    Glass(Modifier.fillMaxWidth().height(52.dp), RoundedCornerShape(26.dp)) {
        Box(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentAlignment = Alignment.CenterStart) {
            if (value.isEmpty()) Text(hint, color = Color.White.copy(alpha = 0.45f))
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Accent),
                visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (password) KeyboardType.Password else KeyboardType.Text
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/** Sign-in / sign-up form. Accounts need a server, so this is interface only. */
@Composable
fun AuthDialog(signUp: Boolean, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss) {
        Glass(Modifier.fillMaxWidth(), RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text(
                    stringResource(if (signUp) R.string.sign_up else R.string.sign_in),
                    color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(16.dp))
                if (signUp) {
                    GlassField(name, { name = it }, stringResource(R.string.name_hint))
                    Spacer(Modifier.height(10.dp))
                }
                GlassField(email, { email = it }, stringResource(R.string.email_hint))
                Spacer(Modifier.height(10.dp))
                GlassField(password, { password = it }, stringResource(R.string.password_hint), password = true)
                if (notice) {
                    Spacer(Modifier.height(12.dp))
                    Text(stringResource(R.string.account_server), color = Accent, fontSize = 13.sp)
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton(stringResource(R.string.close), Modifier.weight(1f), filled = false) { onDismiss() }
                    PillButton(stringResource(R.string.submit), Modifier.weight(1f)) { notice = true }
                }
            }
        }
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            title, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 8.dp, bottom = 6.dp)
        )
        Glass(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp)) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp),
                content = content
            )
        }
    }
}

@Composable
fun SettingsContent(vm: MusicViewModel) {
    val glass by vm.glass.collectAsStateWithLifecycle()
    val accentIdx by vm.accent.collectAsStateWithLifecycle()
    val clear by vm.clear.collectAsStateWithLifecycle()
    val autoScan by vm.autoScan.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val isRussian = LocalConfiguration.current.locales[0].language == "ru"
    var confirmReset by remember { mutableStateOf(false) }
    val switchColors = SwitchDefaults.colors(
        checkedThumbColor = Color.Black,
        checkedTrackColor = Accent,
        uncheckedThumbColor = Color.White,
        uncheckedTrackColor = Color(0xFF3A3A3A)
    )
    val version = remember {
        try {
            context.packageManager
                .getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of(0))
                .versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SettingsGroup(stringResource(R.string.group_appearance)) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.language), color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                LangPill("RU", isRussian) { setAppLanguage(context, "ru") }
                Spacer(Modifier.width(8.dp))
                LangPill("EN", !isRussian) { setAppLanguage(context, "en") }
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.liquid_glass), color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Switch(checked = glass, onCheckedChange = { vm.setGlass(it) }, colors = switchColors)
            }
            Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                Text(stringResource(R.string.glass_clear), color = Color.White, fontSize = 17.sp)
                GlassSlider(
                    value = clear,
                    onValueChange = { vm.setClear(it) },
                    valueRange = 0f..1f,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                )
            }
            Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                Text(stringResource(R.string.accent_color), color = Color.White, fontSize = 17.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Palettes.forEachIndexed { i, p ->
                        val chosen = i == accentIdx
                        Box(
                            Modifier
                                .size(36.dp)
                                .pressScale(onClick = { vm.setAccent(i) })
                                .clip(CircleShape)
                                .background(p.accent)
                                .border(
                                    if (chosen) 3.dp else 1.dp,
                                    if (chosen) Color.White else Color.White.copy(alpha = 0.3f),
                                    CircleShape
                                )
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
        }

        SettingsGroup(stringResource(R.string.group_library)) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.auto_scan), color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Switch(checked = autoScan, onCheckedChange = { vm.setAutoScan(it) }, colors = switchColors)
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PillButton(stringResource(R.string.rescan), Modifier.weight(1f), filled = false) { vm.scan() }
                PillButton(stringResource(R.string.reset_covers), Modifier.weight(1f), filled = false) {
                    confirmReset = true
                }
            }
        }

        SettingsGroup(stringResource(R.string.group_about)) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.app_name), color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(stringResource(R.string.version_fmt, version), color = Color.White.copy(alpha = 0.55f), fontSize = 14.sp)
            }
        }
    }

    if (confirmReset) {
        ConfirmDialog(
            text = stringResource(R.string.reset_covers_confirm),
            confirmRes = R.string.reset_all,
            onConfirm = {
                confirmReset = false
                vm.resetCovers()
            },
            onDismiss = { confirmReset = false }
        )
    }
}

@Composable
private fun LangPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .pressScale(onClick = onClick)
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) Accent else Color.White.copy(alpha = 0.10f))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Color.Black else Color.White, fontWeight = FontWeight.SemiBold)
    }
}

// ───────────────────────── Lists, search, playlists ─────────────────────────

@Composable
fun SongsLazyList(
    vm: MusicViewModel,
    songs: List<Song>,
    underBar: Boolean = false,
    header: (@Composable () -> Unit)? = null,
    onRemove: ((Song) -> Unit)? = null
) {
    val player by vm.player.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val state = rememberLazyListState()
    val glow = LocalGlow.current
    val density = LocalDensity.current
    val topInset = LocalTopInset.current
    val topPx = with(density) { topInset.toPx() }
    val bottomPx = with(density) { 190.dp.toPx() }
    val byId = remember(songs) { songs.associateBy { it.id } }

    // Which tracks currently sit under the top / bottom bars -> blurred light behind the bars
    LaunchedEffect(state, byId, underBar, topPx) {
        snapshotFlow {
            val info = state.layoutInfo
            val pad = if (underBar) topPx else 0f
            val h = info.viewportSize.height
            val top = if (underBar) {
                info.visibleItemsInfo
                    .filter { it.offset + pad < topPx && it.offset + pad + it.size > 0 }
                    .mapNotNull { item -> (item.key as? Long)?.let { byId[it] } }
                    .take(4)
            } else emptyList()
            val bottom = info.visibleItemsInfo
                .filter { it.offset + pad + it.size > h - bottomPx }
                .mapNotNull { item -> (item.key as? Long)?.let { byId[it] } }
                .take(4)
            Pair(top, bottom)
        }.collect { p ->
            glow.top = p.first
            glow.bottom = p.second
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            glow.top = emptyList()
            glow.bottom = emptyList()
        }
    }

    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize().let { if (underBar) it.fadeTop(topPx) else it },
        contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp,
            top = if (underBar) topInset else 0.dp,
            bottom = 200.dp
        )
    ) {
        if (header != null) {
            item(key = "header") { header() }
        }
        items(songs, key = { it.id }) { song ->
            val remove: (() -> Unit)? = if (onRemove != null) ({ onRemove(song) }) else null
            SongRow(song, player.current?.id == song.id, song.id in favs, remove) {
                vm.play(song, songs)
            }
        }
    }
}

@Composable
fun CenterText(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White.copy(alpha = 0.6f), textAlign = TextAlign.Center)
    }
}

@Composable
fun SearchScreen(vm: MusicViewModel) {
    val library by vm.library.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val songs = (library as? LibraryState.Ready)?.songs ?: emptyList()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        try {
            focus.requestFocus()
        } catch (e: Exception) {
            // The field is not ready yet; the user can tap it.
        }
    }
    val filtered = remember(songs, query) {
        val q = query.trim()
        if (q.isEmpty()) emptyList()
        else songs.filter {
            it.title.contains(q, ignoreCase = true) || (it.artist?.contains(q, ignoreCase = true) == true)
        }
    }
    Column(Modifier.fillMaxSize()) {
        SearchField(query, focus) { vm.setQuery(it) }
        Spacer(Modifier.height(8.dp))
        when {
            query.isBlank() -> CenterText(stringResource(R.string.search_empty))
            filtered.isEmpty() -> CenterText(stringResource(R.string.no_results))
            else -> SongsLazyList(vm, filtered)
        }
    }
}

@Composable
fun PlaylistsScreen(
    vm: MusicViewModel,
    songs: List<Song>,
    selected: String?,
    onSelect: (String?) -> Unit
) {
    if (selected != null) {
        PlaylistDetail(vm, songs, selected) { onSelect(null) }
        return
    }
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val songMap = remember(songs) { songs.associateBy { it.id } }
    var creating by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                stringResource(R.string.playlists),
                style = TextStyle(
                    color = Color.White, fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic
                )
            )
            Glass(Modifier.size(46.dp).pressScale(onClick = { creating = true }), CircleShape) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Add, stringResource(R.string.new_playlist), tint = Accent)
                }
            }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 8.dp, bottom = 220.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                PlaylistCard(
                    title = stringResource(R.string.favorites),
                    count = favs.count { it in songMap },
                    cover = songs.firstOrNull { it.id in favs },
                    heart = true
                ) { onSelect("fav") }
            }
            items(playlists, key = { it.id }) { p ->
                PlaylistCard(
                    title = p.name,
                    count = p.songIds.count { it in songMap },
                    cover = p.songIds.firstNotNullOfOrNull { songMap[it] },
                    heart = false
                ) { onSelect(p.id) }
            }
            if (playlists.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.no_playlists),
                        color = Color.White.copy(alpha = 0.55f),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp)
                    )
                }
            }
        }
    }

    if (creating) {
        NamePlaylistDialog(
            titleRes = R.string.new_playlist,
            initial = "",
            confirmRes = R.string.create,
            onConfirm = { name ->
                vm.createPlaylist(name)
                creating = false
            },
            onDismiss = { creating = false }
        )
    }
}

@Composable
fun PlaylistCard(title: String, count: Int, cover: Song?, heart: Boolean, onClick: () -> Unit) {
    Glass(Modifier.fillMaxWidth().pressScale(onClick = onClick), RoundedCornerShape(22.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (heart) {
                Box(
                    Modifier
                        .size(60.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Accent.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Star, null, tint = Accent, modifier = Modifier.size(30.dp))
                }
            } else {
                Artwork(cover, Modifier.size(60.dp), 160, RoundedCornerShape(14.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(
                    title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    stringResource(R.string.songs_count, count),
                    color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp
                )
            }
            Text("›", color = Color.White.copy(alpha = 0.5f), fontSize = 22.sp)
        }
    }
}

@Composable
fun PlaylistDetail(vm: MusicViewModel, songs: List<Song>, id: String, onBack: () -> Unit) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val isFav = id == "fav"
    val playlist = playlists.firstOrNull { it.id == id }
    if (!isFav && playlist == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val songMap = remember(songs) { songs.associateBy { it.id } }
    val list = if (isFav) songs.filter { it.id in favs }
    else (playlist?.songIds ?: emptyList()).mapNotNull { songMap[it] }
    val title = if (isFav) stringResource(R.string.favorites) else (playlist?.name ?: "")
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.pressScale(onClick = onBack).padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back), tint = Color.White)
            Spacer(Modifier.width(10.dp))
            Text(stringResource(R.string.playlists), color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = TextStyle(
                        color = Color.White, fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic
                    ),
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    stringResource(R.string.songs_count, list.size),
                    color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp
                )
            }
            if (!isFav) {
                IconBtn(Icons.Rounded.Edit, size = 24.dp, description = stringResource(R.string.rename)) { renaming = true }
                IconBtn(Icons.Rounded.Delete, size = 24.dp, description = stringResource(R.string.delete)) { deleting = true }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PillButton(stringResource(R.string.play), Modifier.weight(1f)) {
                if (list.isNotEmpty()) vm.play(list.first(), list)
            }
            PillButton(stringResource(R.string.shuffle), Modifier.weight(1f), filled = false) {
                vm.playShuffled(list)
            }
        }
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) {
            CenterText(stringResource(if (isFav) R.string.no_favorites else R.string.empty_playlist))
        } else {
            SongsLazyList(vm, list) { s ->
                if (isFav) vm.toggleFavorite(s.id) else vm.removeFromPlaylist(id, s.id)
            }
        }
    }

    if (renaming) {
        NamePlaylistDialog(
            titleRes = R.string.rename,
            initial = playlist?.name ?: "",
            confirmRes = R.string.save,
            onConfirm = { name ->
                vm.renamePlaylist(id, name)
                renaming = false
            },
            onDismiss = { renaming = false }
        )
    }
    if (deleting) {
        ConfirmDialog(
            text = stringResource(R.string.delete_confirm),
            confirmRes = R.string.delete,
            onConfirm = {
                deleting = false
                vm.deletePlaylist(id)
                onBack()
            },
            onDismiss = { deleting = false }
        )
    }
}

// ───────────────────────── Dialogs ─────────────────────────

@Composable
fun NamePlaylistDialog(
    titleRes: Int,
    initial: String,
    confirmRes: Int,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial) }
    Dialog(onDismissRequest = onDismiss) {
        Glass(Modifier.fillMaxWidth(), RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text(stringResource(titleRes), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                GlassField(name, { name = it }, stringResource(R.string.playlist_name))
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton(stringResource(R.string.cancel), Modifier.weight(1f), filled = false) { onDismiss() }
                    PillButton(stringResource(confirmRes), Modifier.weight(1f)) {
                        if (name.isNotBlank()) onConfirm(name.trim())
                    }
                }
            }
        }
    }
}

@Composable
fun ConfirmDialog(text: String, confirmRes: Int, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Glass(Modifier.fillMaxWidth(), RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text(text, color = Color.White, fontSize = 17.sp)
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton(stringResource(R.string.cancel), Modifier.weight(1f), filled = false) { onDismiss() }
                    PillButton(stringResource(confirmRes), Modifier.weight(1f)) { onConfirm() }
                }
            }
        }
    }
}

@Composable
fun MenuItem(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .pressScale(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint)
        Spacer(Modifier.width(14.dp))
        Text(label, color = Color.White, fontSize = 16.sp)
    }
}

/** Options for one song: favorite, add to playlist, change or reset the cover. */
@Composable
fun SongMenuDialog(
    song: Song,
    vm: MusicViewModel,
    onDismiss: () -> Unit,
    onPickCover: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit
) {
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val version by CoverStore.version.collectAsState()
    val hasCover = remember(song.id, version) { CoverStore.has(context, song.id) }
    val isFav = song.id in favs
    Dialog(onDismissRequest = onDismiss) {
        Glass(Modifier.fillMaxWidth(), RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(vertical = 8.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Artwork(song, Modifier.size(52.dp), 128)
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(
                            song.title, color = Color.White, fontWeight = FontWeight.Bold,
                            fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        if (song.artist != null) {
                            Text(song.artist, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, maxLines = 1)
                        }
                    }
                }
                MenuItem(
                    if (isFav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    stringResource(if (isFav) R.string.remove_fav else R.string.add_to_fav),
                    tint = Accent
                ) {
                    vm.toggleFavorite(song.id)
                    onDismiss()
                }
                MenuItem(Icons.Rounded.Add, stringResource(R.string.add_to_playlist)) {
                    onDismiss()
                    onAddToPlaylist(song)
                }
                MenuItem(Icons.Rounded.Image, stringResource(R.string.change_cover)) {
                    onDismiss()
                    onPickCover(song)
                }
                if (hasCover) {
                    MenuItem(Icons.Rounded.Close, stringResource(R.string.reset_cover)) {
                        vm.resetCover(song)
                        onDismiss()
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistPickerDialog(song: Song, vm: MusicViewModel, onDismiss: () -> Unit) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        NamePlaylistDialog(
            titleRes = R.string.new_playlist,
            initial = "",
            confirmRes = R.string.create,
            onConfirm = { name ->
                val p = vm.createPlaylist(name)
                vm.addToPlaylist(p.id, song.id)
                onDismiss()
            },
            onDismiss = { creating = false }
        )
        return
    }
    Dialog(onDismissRequest = onDismiss) {
        Glass(Modifier.fillMaxWidth(), RoundedCornerShape(28.dp)) {
            Column(
                Modifier
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 12.dp)
            ) {
                Text(
                    stringResource(R.string.choose_playlist), color = Color.White,
                    fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
                MenuItem(Icons.Rounded.Add, stringResource(R.string.new_playlist), tint = Accent) {
                    creating = true
                }
                playlists.forEach { p ->
                    MenuItem(Icons.Rounded.Album, p.name) {
                        vm.addToPlaylist(p.id, song.id)
                        onDismiss()
                    }
                }
            }
        }
    }
}
