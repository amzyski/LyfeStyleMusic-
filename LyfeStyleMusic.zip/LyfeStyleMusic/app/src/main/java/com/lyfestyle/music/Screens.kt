package com.lyfestyle.music

import android.Manifest
import android.app.LocaleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.LocaleList
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class MainTab { Library, Profile }

fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

fun setAppLanguage(context: Context, tag: String) {
    val manager = context.getSystemService(LocaleManager::class.java)
    manager.applicationLocales = LocaleList.forLanguageTags(tag)
}

// ───────────────────────── Root ─────────────────────────

@Composable
fun AppRoot(vm: MusicViewModel) {
    val glass by vm.glass.collectAsStateWithLifecycle()
    var splash by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(2300)
        splash = false
    }
    CompositionLocalProvider(LocalGlass provides glass) {
        Crossfade(targetState = splash, animationSpec = tween(600), label = "splash") { showSplash ->
            if (showSplash) SplashScreen() else MainScaffold(vm)
        }
    }
}

@Composable
fun SplashScreen() {
    val scale = remember { Animatable(0.8f) }
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { fade.animateTo(1f, tween(900)) }
        scale.animateTo(1f, tween(1500, easing = FastOutSlowInEasing))
    }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = stringResource(R.string.logo),
            modifier = Modifier
                .fillMaxWidth(0.72f)
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                    alpha = fade.value
                }
        )
    }
}

@Composable
fun MainScaffold(vm: MusicViewModel) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(MainTab.Library) }
    var playerOpen by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    val ui by vm.player.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        if (vm.settings.scannedBefore && hasAudioPermission(context) &&
            vm.library.value is LibraryState.Idle
        ) vm.scan()
    }

    BackHandler(enabled = playerOpen) { playerOpen = false }
    BackHandler(enabled = !playerOpen && tab == MainTab.Profile && showSettings) {
        showSettings = false
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (LocalGlass.current) BlurBackdrop(ui.current, 0.30f)
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.55f), Color.Black.copy(alpha = 0.88f))
                    )
                )
        )

        Column(Modifier.fillMaxSize()) {
            TopBar(vm.settings.userName) {
                tab = MainTab.Profile
                showSettings = false
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        (fadeIn(tween(320)) + scaleIn(initialScale = 0.96f, animationSpec = tween(320))) togetherWith
                            fadeOut(tween(180))
                    },
                    label = "tab"
                ) { t ->
                    when (t) {
                        MainTab.Library -> LibraryScreen(vm)
                        MainTab.Profile -> ProfileScreen(vm, showSettings) { showSettings = it }
                    }
                }
            }
        }

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 12.dp)
        ) {
            if (ui.current != null) {
                MiniPlayer(vm, ui) { playerOpen = true }
                Spacer(Modifier.height(10.dp))
            }
            BottomBar(tab) {
                tab = it
                if (it != MainTab.Profile) showSettings = false
            }
        }

        AnimatedVisibility(
            visible = playerOpen && ui.current != null,
            enter = slideInVertically(tween(450, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300)),
            exit = slideOutVertically(tween(350)) { it } + fadeOut(tween(250))
        ) {
            PlayerScreen(vm) { playerOpen = false }
        }
    }
}

// ───────────────────────── Bars ─────────────────────────

@Composable
fun TopBar(userName: String?, onAvatar: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            stringResource(R.string.app_name),
            style = TextStyle(
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                fontStyle = FontStyle.Italic
            ),
            maxLines = 1
        )
        Glass(Modifier.size(44.dp).pressScale(onClick = onAvatar), CircleShape) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (userName != null) {
                    Text(
                        userName.take(1).uppercase(), color = Color.White,
                        fontWeight = FontWeight.Bold, fontSize = 18.sp
                    )
                } else {
                    Icon(Icons.Rounded.Person, stringResource(R.string.profile), tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun BottomBar(tab: MainTab, onTab: (MainTab) -> Unit) {
    Glass(
        Modifier
            .padding(horizontal = 40.dp)
            .fillMaxWidth()
            .height(68.dp),
        RoundedCornerShape(34.dp)
    ) {
        BoxWithConstraints(Modifier.fillMaxSize().padding(6.dp)) {
            val itemWidth = maxWidth / 2
            val x by animateDpAsState(
                targetValue = itemWidth * tab.ordinal,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 300f),
                label = "indicator"
            )
            Box(
                Modifier
                    .offset(x = x)
                    .width(itemWidth)
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.16f))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
            )
            Row(Modifier.fillMaxSize()) {
                BarItem(Modifier.weight(1f), Icons.Rounded.LibraryMusic, R.string.library, tab == MainTab.Library) {
                    onTab(MainTab.Library)
                }
                BarItem(Modifier.weight(1f), Icons.Rounded.Person, R.string.profile, tab == MainTab.Profile) {
                    onTab(MainTab.Profile)
                }
            }
        }
    }
}

@Composable
private fun BarItem(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: Int,
    selected: Boolean,
    onClick: () -> Unit
) {
    val color = if (selected) Accent else Color.White.copy(alpha = 0.65f)
    Column(
        modifier.fillMaxSize().pressScale(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(24.dp))
        Text(stringResource(label), color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

// ───────────────────────── Library ─────────────────────────

@Composable
fun LibraryScreen(vm: MusicViewModel) {
    val state by vm.library.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var denied by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasAudioPermission(context)) {
            denied = false
            vm.scan()
        } else {
            denied = true
        }
    }
    val start: () -> Unit = {
        val need = listOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            .filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) vm.scan() else launcher.launch(need.toTypedArray())
    }

    when (val s = state) {
        LibraryState.Idle ->
            if (denied) {
                PermissionDenied(onGrant = start, onSettings = {
                    context.startActivity(
                        Intent(
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", context.packageName, null)
                        )
                    )
                })
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    FindMusicButton(start)
                }
            }

        LibraryState.Loading ->
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(color = Accent)
                Spacer(Modifier.height(16.dp))
                Text(stringResource(R.string.scanning), color = Color.White.copy(alpha = 0.7f))
            }

        is LibraryState.Error ->
            MessageBlock(
                stringResource(R.string.scan_error), s.message,
                stringResource(R.string.retry), start
            )

        is LibraryState.Ready ->
            if (s.songs.isEmpty()) {
                MessageBlock(
                    stringResource(R.string.empty_title), stringResource(R.string.empty_text),
                    stringResource(R.string.rescan), start
                )
            } else {
                SongList(vm, s.songs)
            }
    }
}

@Composable
fun FindMusicButton(onClick: () -> Unit) {
    Glass(Modifier.padding(24.dp).pressScale(onClick = onClick), RoundedCornerShape(36.dp)) {
        Row(
            Modifier.padding(horizontal = 28.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.LibraryMusic, null, tint = Accent)
            Spacer(Modifier.width(12.dp))
            Text(
                stringResource(R.string.find_music), color = Color.White,
                fontSize = 18.sp, fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun PillButton(text: String, modifier: Modifier = Modifier, filled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Box(
        modifier
            .height(52.dp)
            .pressScale(onClick = onClick)
            .clip(shape)
            .background(if (filled) Accent else Color.White.copy(alpha = 0.10f))
            .border(1.dp, if (filled) Accent else Color.White.copy(alpha = 0.25f), shape)
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = if (filled) Color.Black else Color.White,
            fontWeight = FontWeight.SemiBold, fontSize = 16.sp
        )
    }
}

@Composable
fun MessageBlock(title: String, text: String, button: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        if (text.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(text, color = Color.White.copy(alpha = 0.6f), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
        PillButton(button, onClick = onClick)
    }
}

@Composable
fun PermissionDenied(onGrant: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            stringResource(R.string.permission_title), color = Color.White, fontSize = 22.sp,
            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.permission_text), color = Color.White.copy(alpha = 0.6f),
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        PillButton(stringResource(R.string.grant), onClick = onGrant)
        Spacer(Modifier.height(12.dp))
        PillButton(stringResource(R.string.open_settings), filled = false, onClick = onSettings)
    }
}

@Composable
fun SongList(vm: MusicViewModel, songs: List<Song>) {
    val query by vm.query.collectAsStateWithLifecycle()
    val player by vm.player.collectAsStateWithLifecycle()
    val filtered = remember(songs, query) {
        val q = query.trim()
        if (q.isEmpty()) songs
        else songs.filter {
            it.title.contains(q, ignoreCase = true) || (it.artist?.contains(q, ignoreCase = true) == true)
        }
    }
    Column(Modifier.fillMaxSize()) {
        SearchBar(query) { vm.setQuery(it) }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                stringResource(R.string.songs_count, filtered.size),
                color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp
            )
            Box(
                Modifier.size(36.dp).pressScale(onClick = { vm.scan() }),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Refresh, stringResource(R.string.rescan),
                    tint = Color.White.copy(alpha = 0.7f)
                )
            }
        }
        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.no_results), color = Color.White.copy(alpha = 0.6f))
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 220.dp)
            ) {
                items(filtered, key = { it.id }) { song ->
                    SongRow(song, player.current?.id == song.id) { vm.play(song, filtered) }
                }
            }
        }
    }
}

@Composable
fun SearchBar(query: String, onChange: (String) -> Unit) {
    Glass(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(52.dp),
        RoundedCornerShape(26.dp)
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Search, null, tint = Color.White.copy(alpha = 0.6f))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(stringResource(R.string.search_hint), color = Color.White.copy(alpha = 0.45f))
                }
                BasicTextField(
                    value = query,
                    onValueChange = onChange,
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Accent),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (query.isNotEmpty()) {
                Box(Modifier.size(32.dp).pressScale(onClick = { onChange("") }), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Close, stringResource(R.string.close), tint = Color.White.copy(alpha = 0.7f))
                }
            }
        }
    }
}

@Composable
fun SongRow(song: Song, current: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().pressScale(onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(song, Modifier.size(54.dp), 192)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(
                song.title, color = if (current) Accent else Color.White,
                fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            val sub = listOfNotNull(song.artist, song.album).joinToString(" · ")
            if (sub.isNotEmpty()) {
                Text(
                    sub, color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        Text(formatTime(song.durationMs), color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
    }
}

// ───────────────────────── Profile ─────────────────────────

@Composable
fun ProfileScreen(vm: MusicViewModel, showSettings: Boolean, setShowSettings: (Boolean) -> Unit) {
    if (showSettings) {
        SettingsScreen(vm) { setShowSettings(false) }
        return
    }
    val stats by vm.stats.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()
    val songsCount = (library as? LibraryState.Ready)?.songs?.size ?: 0
    var auth by remember { mutableStateOf<String?>(null) }
    val userName = vm.settings.userName

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 220.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(8.dp))
        Glass(Modifier.size(104.dp), CircleShape) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (userName != null) {
                    Text(userName.take(1).uppercase(), color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Rounded.Person, null, tint = Color.White, modifier = Modifier.size(52.dp))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            userName ?: stringResource(R.string.guest), color = Color.White,
            fontSize = 24.sp, fontWeight = FontWeight.Bold
        )
        if (userName == null) {
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.local_mode), color = Color.White.copy(alpha = 0.55f),
                fontSize = 13.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PillButton(stringResource(R.string.sign_in), Modifier.weight(1f)) { auth = "in" }
                PillButton(stringResource(R.string.sign_up), Modifier.weight(1f), filled = false) { auth = "up" }
            }
        }
        Spacer(Modifier.height(16.dp))

        Glass(Modifier.fillMaxWidth().pressScale(onClick = { setShowSettings(true) }), RoundedCornerShape(24.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Settings, null, tint = Accent)
                Spacer(Modifier.width(14.dp))
                Text(stringResource(R.string.settings), color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text("›", color = Color.White.copy(alpha = 0.5f), fontSize = 22.sp)
            }
        }

        Spacer(Modifier.height(24.dp))
        Text(
            stringResource(R.string.stats), color = Color.White, fontSize = 20.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        val minutes = stats.listenedMs / 60000
        val timeText = if (minutes >= 60) stringResource(R.string.time_hm, minutes / 60, minutes % 60)
        else stringResource(R.string.time_m, minutes)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(Modifier.weight(1f), timeText, stringResource(R.string.stat_time))
            StatTile(Modifier.weight(1f), stats.totalPlays.toString(), stringResource(R.string.stat_plays))
            StatTile(Modifier.weight(1f), songsCount.toString(), stringResource(R.string.stat_library))
        }
        Spacer(Modifier.height(16.dp))
        Glass(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text(stringResource(R.string.top_tracks), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                if (stats.top.isEmpty()) {
                    Text(stringResource(R.string.no_stats), color = Color.White.copy(alpha = 0.55f), fontSize = 14.sp)
                } else {
                    stats.top.forEachIndexed { i, t ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp))
                            Column(Modifier.weight(1f)) {
                                Text(t.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (t.artist != null) {
                                    Text(t.artist, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Text("×${t.count}", color = Color.White.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }

    auth?.let { mode -> AuthDialog(signUp = mode == "up") { auth = null } }
}

@Composable
fun StatTile(modifier: Modifier, value: String, label: String) {
    Glass(modifier, RoundedCornerShape(20.dp)) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Text(label, color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun GlassField(value: String, onChange: (String) -> Unit, hint: String, password: Boolean = false) {
    Glass(Modifier.fillMaxWidth().height(52.dp), RoundedCornerShape(26.dp)) {
        Box(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentAlignment = Alignment.CenterStart) {
            if (value.isEmpty()) Text(hint, color = Color.White.copy(alpha = 0.45f))
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Accent),
                visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (password) KeyboardType.Password else KeyboardType.Text
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/** Sign-in / sign-up form. Accounts need a server, so this is interface only. */
@Composable
fun AuthDialog(signUp: Boolean, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss) {
        Glass(Modifier.fillMaxWidth(), RoundedCornerShape(28.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text(
                    stringResource(if (signUp) R.string.sign_up else R.string.sign_in),
                    color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(16.dp))
                if (signUp) {
                    GlassField(name, { name = it }, stringResource(R.string.name_hint))
                    Spacer(Modifier.height(10.dp))
                }
                GlassField(email, { email = it }, stringResource(R.string.email_hint))
                Spacer(Modifier.height(10.dp))
                GlassField(password, { password = it }, stringResource(R.string.password_hint), password = true)
                if (notice) {
                    Spacer(Modifier.height(12.dp))
                    Text(stringResource(R.string.account_server), color = Accent, fontSize = 13.sp)
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton(stringResource(R.string.close), Modifier.weight(1f), filled = false) { onDismiss() }
                    PillButton(stringResource(R.string.submit), Modifier.weight(1f)) { notice = true }
                }
            }
        }
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
fun SettingsScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val glass by vm.glass.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val isRussian = LocalConfiguration.current.locales[0].language == "ru"

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 220.dp)
    ) {
        Row(
            Modifier.pressScale(onClick = onBack).padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back), tint = Color.White)
            Spacer(Modifier.width(10.dp))
            Text(stringResource(R.string.settings), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.language), color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    LangPill("RU", isRussian) { setAppLanguage(context, "ru") }
                    Spacer(Modifier.width(8.dp))
                    LangPill("EN", !isRussian) { setAppLanguage(context, "en") }
                }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.liquid_glass), color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = glass,
                        onCheckedChange = { vm.setGlass(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = Accent,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = Color(0xFF3A3A3A)
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun LangPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .pressScale(onClick = onClick)
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) Accent else Color.White.copy(alpha = 0.10f))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Color.Black else Color.White, fontWeight = FontWeight.SemiBold)
    }
}
