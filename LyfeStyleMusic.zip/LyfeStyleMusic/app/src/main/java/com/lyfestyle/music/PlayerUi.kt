package com.lyfestyle.music

import android.content.Intent
import android.media.AudioManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeDown
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import kotlin.math.roundToInt

@Composable
fun IconBtn(
    icon: ImageVector,
    tint: Color = Color.White,
    size: Dp = 28.dp,
    description: String? = null,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(48.dp)
            .pressScale(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, description, modifier = Modifier.size(size), tint = tint)
    }
}

/** Glass pill with a glowing rim, shown above the bottom bar while a song is loaded. */
@Composable
fun MiniPlayer(vm: MusicViewModel, ui: PlayerUi, onOpen: () -> Unit) {
    val song = ui.current ?: return
    Glass(
        Modifier
            .padding(horizontal = 14.dp)
            .fillMaxWidth()
            .height(64.dp)
            .pressScale(onClick = onOpen),
        RoundedCornerShape(32.dp),
        rimAlpha = 0.9f,
        rimColor = Accent
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Artwork(song, Modifier.size(48.dp), 128, RoundedCornerShape(14.dp), depth = true)
            Column(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 14.dp)
            ) {
                Text(
                    song.title, color = Color.White, fontWeight = FontWeight.SemiBold,
                    fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (song.artist != null) {
                    Text(
                        song.artist, color = Color.White.copy(alpha = 0.6f),
                        fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconBtn(
                if (ui.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                size = 34.dp,
                description = stringResource(if (ui.playing) R.string.pause else R.string.play)
            ) { vm.togglePlay() }
            IconBtn(
                Icons.Rounded.SkipNext, size = 34.dp,
                description = stringResource(R.string.next)
            ) { vm.next() }
        }
    }
}

/** Full-screen player: big cover, favorite star, thin purple sliders, queue. */
@Composable
fun PlayerScreen(vm: MusicViewModel, onClose: () -> Unit) {
    val ui by vm.player.collectAsStateWithLifecycle()
    val song = ui.current ?: return
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    var showQueue by remember { mutableStateOf(false) }
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val isFav = song.id in favs
    val openMenu = LocalOpenSongMenu.current
    val addToPlaylist = LocalAddToPlaylist.current

    val context = LocalContext.current
    val audio = remember { context.getSystemService(AudioManager::class.java) }
    val maxVolume = remember {
        audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat().coerceAtLeast(1f)
    }
    var volume by remember {
        mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat())
    }
    val duration = ui.duration.coerceAtLeast(1L).toFloat()
    val position = ui.position.toFloat().coerceIn(0f, duration)
    val accent = Accent
    val soft = accent.copy(alpha = 0.7f)
    val dim = Color.White.copy(alpha = 0.6f)

    Box(Modifier.fillMaxSize()) {
        AppBackground(song)
        BlurBackdrop(song, 0.30f)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircleButton(
                    Icons.Rounded.KeyboardArrowDown, stringResource(R.string.close),
                    tint = accent, onClick = onClose
                )
                CircleButton(
                    Icons.Rounded.MoreHoriz, stringResource(R.string.more),
                    tint = accent
                ) { openMenu(song) }
            }

            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth().padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                val side = minOf(maxWidth, maxHeight).coerceAtLeast(120.dp)
                val scale by animateFloatAsState(
                    targetValue = if (ui.playing) 1f else 0.88f,
                    animationSpec = spring(dampingRatio = 0.55f, stiffness = 200f),
                    label = "cover"
                )
                Artwork(
                    song,
                    Modifier
                        .size(side)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        },
                    1024,
                    RoundedCornerShape(28.dp),
                    depth = true
                )
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title, color = Color.White, fontWeight = FontWeight.Bold,
                        fontSize = 28.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    val sub = listOfNotNull(song.artist, song.album).joinToString(" · ")
                    if (sub.isNotEmpty()) {
                        Text(
                            sub, color = soft, fontSize = 20.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                CircleButton(
                    if (isFav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    stringResource(if (isFav) R.string.remove_fav else R.string.add_to_fav),
                    size = 46.dp, tint = accent
                ) { vm.toggleFavorite(song.id) }
                Spacer(Modifier.width(10.dp))
                CircleButton(
                    Icons.Rounded.MoreHoriz, stringResource(R.string.more),
                    size = 46.dp, tint = accent
                ) { openMenu(song) }
            }

            Spacer(Modifier.height(14.dp))
            GlassSlider(
                value = if (dragging) dragValue else position,
                onValueChange = {
                    dragging = true
                    dragValue = it
                },
                valueRange = 0f..duration,
                modifier = Modifier.fillMaxWidth(),
                color = accent,
                onFinished = {
                    vm.seekTo(dragValue.toLong())
                    dragging = false
                }
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val shown = if (dragging) dragValue else position
                Text(formatTime(shown.toLong()), color = dim, fontSize = 13.sp)
                Text("-" + formatTime((duration - shown).toLong()), color = dim, fontSize = 13.sp)
            }

            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBtn(
                    Icons.Rounded.Shuffle,
                    tint = if (ui.shuffle) accent else soft,
                    description = stringResource(R.string.shuffle)
                ) { vm.toggleShuffle() }
                IconBtn(
                    Icons.Rounded.FastRewind, size = 46.dp,
                    description = stringResource(R.string.previous)
                ) { vm.previous() }
                Box(
                    Modifier.size(84.dp).pressScale(onClick = { vm.togglePlay() }),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (ui.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        stringResource(if (ui.playing) R.string.pause else R.string.play),
                        modifier = Modifier.size(68.dp),
                        tint = Color.White
                    )
                }
                IconBtn(
                    Icons.Rounded.FastForward, size = 46.dp,
                    description = stringResource(R.string.next)
                ) { vm.next() }
                IconBtn(
                    if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    tint = if (ui.repeat != Player.REPEAT_MODE_OFF) accent else soft,
                    description = stringResource(R.string.repeat)
                ) { vm.cycleRepeat() }
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.AutoMirrored.Rounded.VolumeDown, null, tint = soft)
                GlassSlider(
                    value = volume,
                    onValueChange = {
                        volume = it
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, it.roundToInt(), 0)
                    },
                    valueRange = 0f..maxVolume,
                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                    color = accent.copy(alpha = 0.8f),
                    thumb = false
                )
                Icon(Icons.AutoMirrored.Rounded.VolumeUp, null, tint = soft)
            }

            Spacer(Modifier.height(4.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBtn(
                    Icons.Rounded.Add, tint = accent,
                    description = stringResource(R.string.add_to_playlist)
                ) { addToPlaylist(song) }
                IconBtn(Icons.Rounded.Cast, tint = accent, size = 32.dp) {
                    try {
                        context.startActivity(
                            Intent(android.provider.Settings.Panel.ACTION_VOLUME)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) {
                        // No output panel on this device.
                    }
                }
                IconBtn(
                    Icons.Rounded.FormatListBulleted, tint = accent,
                    description = stringResource(R.string.queue_title)
                ) { showQueue = true }
            }
        }
    }

    if (showQueue) QueueDialog(vm) { showQueue = false }
}

/** The songs that play next, tap one to jump to it. */
@Composable
fun QueueDialog(vm: MusicViewModel, onDismiss: () -> Unit) {
    val ui by vm.player.collectAsStateWithLifecycle()
    val queue = remember { vm.queueSongs() }
    Dialog(onDismissRequest = onDismiss) {
        Glass(Modifier.fillMaxWidth().heightIn(max = 520.dp), RoundedCornerShape(28.dp)) {
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
                item {
                    Text(
                        stringResource(R.string.queue_title), color = Color.White,
                        fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                itemsIndexed(queue) { index, s ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .pressScale(onClick = {
                                vm.skipTo(index)
                                onDismiss()
                            })
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Artwork(s, Modifier.size(46.dp), 96, RoundedCornerShape(12.dp), depth = true)
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(
                                s.title,
                                color = if (ui.current?.id == s.id) Accent else Color.White,
                                fontWeight = FontWeight.Medium, fontSize = 16.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            if (s.artist != null) {
                                Text(
                                    s.artist, color = Color.White.copy(alpha = 0.5f),
                                    fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
