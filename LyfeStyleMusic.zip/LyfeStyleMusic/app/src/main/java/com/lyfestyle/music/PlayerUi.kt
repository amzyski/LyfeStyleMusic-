package com.lyfestyle.music

import android.media.AudioManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeDown
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import kotlin.math.roundToInt

@Composable
fun IconBtn(
    icon: ImageVector,
    tint: Color = Color.White,
    size: Dp = 28.dp,
    description: String? = null,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(48.dp)
            .pressScale(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, description, modifier = Modifier.size(size), tint = tint)
    }
}

/** Compact glass pill shown above the bottom bar while a song is loaded. */
@Composable
fun MiniPlayer(vm: MusicViewModel, ui: PlayerUi, onOpen: () -> Unit) {
    val song = ui.current ?: return
    Glass(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .height(58.dp)
            .pressScale(onClick = onOpen),
        RoundedCornerShape(29.dp)
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Artwork(song, Modifier.size(42.dp), 128, RoundedCornerShape(12.dp))
            Column(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    song.title, color = Color.White, fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (song.artist != null) {
                    Text(
                        song.artist, color = Color.White.copy(alpha = 0.6f),
                        fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconBtn(
                if (ui.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                size = 32.dp,
                description = stringResource(if (ui.playing) R.string.pause else R.string.play)
            ) { vm.togglePlay() }
            IconBtn(
                Icons.Rounded.SkipNext, size = 32.dp,
                description = stringResource(R.string.next)
            ) { vm.next() }
        }
    }
}

/** Full-screen "now playing" screen in the style of Apple Music. */
@Composable
fun PlayerScreen(vm: MusicViewModel, onClose: () -> Unit) {
    val ui by vm.player.collectAsStateWithLifecycle()
    val song = ui.current ?: return
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val isFav = song.id in favs
    val openMenu = LocalOpenSongMenu.current

    val context = LocalContext.current
    val audio = remember { context.getSystemService(AudioManager::class.java) }
    val maxVolume = remember {
        audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat().coerceAtLeast(1f)
    }
    var volume by remember {
        mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat())
    }
    val duration = ui.duration.coerceAtLeast(1L).toFloat()
    val position = ui.position.toFloat().coerceIn(0f, duration)
    val dim = Color.White.copy(alpha = 0.7f)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        BlurBackdrop(song, 0.8f)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Glass(Modifier.size(44.dp).pressScale(onClick = onClose), CircleShape) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Rounded.KeyboardArrowDown, stringResource(R.string.close),
                            tint = Color.White
                        )
                    }
                }
                Glass(Modifier.size(44.dp).pressScale(onClick = { openMenu(song) }), CircleShape) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Rounded.MoreVert, stringResource(R.string.more),
                            tint = Color.White
                        )
                    }
                }
            }

            BoxWithConstraints(
                Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val side = (minOf(maxWidth, maxHeight) - 16.dp).coerceAtLeast(120.dp)
                val scale by animateFloatAsState(
                    targetValue = if (ui.playing) 1f else 0.84f,
                    animationSpec = spring(dampingRatio = 0.55f, stiffness = 200f),
                    label = "cover"
                )
                Artwork(
                    song,
                    Modifier
                        .size(side)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        },
                    1024,
                    RoundedCornerShape(24.dp)
                )
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title, color = Color.White, fontWeight = FontWeight.Bold,
                        fontSize = 24.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    val sub = listOfNotNull(song.artist, song.album).joinToString(" · ")
                    if (sub.isNotEmpty()) {
                        Text(
                            sub, color = dim, fontSize = 17.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconBtn(
                    if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    tint = if (isFav) Accent else dim,
                    description = stringResource(if (isFav) R.string.remove_fav else R.string.add_to_fav)
                ) { vm.toggleFavorite(song.id) }
            }

            GlassSlider(
                value = if (dragging) dragValue else position,
                onValueChange = {
                    dragging = true
                    dragValue = it
                },
                valueRange = 0f..duration,
                modifier = Modifier.fillMaxWidth(),
                onFinished = {
                    vm.seekTo(dragValue.toLong())
                    dragging = false
                }
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val shown = if (dragging) dragValue else position
                Text(formatTime(shown.toLong()), color = dim, fontSize = 12.sp)
                Text("-" + formatTime((duration - shown).toLong()), color = dim, fontSize = 12.sp)
            }

            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBtn(
                    Icons.Rounded.Shuffle,
                    tint = if (ui.shuffle) Accent else dim,
                    description = stringResource(R.string.shuffle)
                ) { vm.toggleShuffle() }
                IconBtn(
                    Icons.Rounded.SkipPrevious, size = 40.dp,
                    description = stringResource(R.string.previous)
                ) { vm.previous() }
                Glass(
                    Modifier.size(78.dp).pressScale(onClick = { vm.togglePlay() }),
                    CircleShape
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            if (ui.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            stringResource(if (ui.playing) R.string.pause else R.string.play),
                            modifier = Modifier.size(42.dp),
                            tint = Color.White
                        )
                    }
                }
                IconBtn(
                    Icons.Rounded.SkipNext, size = 40.dp,
                    description = stringResource(R.string.next)
                ) { vm.next() }
                IconBtn(
                    if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    tint = if (ui.repeat != Player.REPEAT_MODE_OFF) Accent else dim,
                    description = stringResource(R.string.repeat)
                ) { vm.cycleRepeat() }
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.AutoMirrored.Rounded.VolumeDown, null, tint = dim)
                GlassSlider(
                    value = volume,
                    onValueChange = {
                        volume = it
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, it.roundToInt(), 0)
                    },
                    valueRange = 0f..maxVolume,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Icon(Icons.AutoMirrored.Rounded.VolumeUp, null, tint = dim)
            }
        }
    }
}
