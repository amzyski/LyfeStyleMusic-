# LyfeStyle Music (Android 15+)

Офлайн-плеер для музыки на устройстве. Kotlin + Jetpack Compose, minSdk 35.

## Сборка APK без Android Studio (GitHub Actions)
0. Вариант с ZIP: создайте в репозитории файл `.github/workflows/build-apk.yml` (скопируйте из архива) и загрузите сам `LyfeStyleMusic.zip` в корень. Workflow распакует его сам.
1. Создайте репозиторий на GitHub и загрузите в него ВСЕ файлы проекта, включая папки `.github` и `gradle`.
   (Папка `.github` скрытая: проверьте, что она загрузилась.)
2. Откройте вкладку Actions. Сборка стартует сама после push, либо нажмите Run workflow.
3. После зелёной галочки откройте запуск и скачайте в разделе Artifacts файл `LyfeStyleMusic-APK`
   (внутри LyfeStyleMusic.apk). Установите его на телефон с Android 15+.
4. Если сборка красная, откройте шаг «Build debug APK» и пришлите текст ошибки.

Версии: AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, JDK 17, compileSdk/targetSdk 35.

## Сборка в Android Studio
File → Open → папка проекта → Build → Build APK(s).
